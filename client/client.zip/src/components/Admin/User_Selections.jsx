import React from 'react'
import MainHeader from '../../pages/MainHeader'
import AdminSider from './AdminSider'

function User_Selections() {
  return (
    <>
    
    
    <MainHeader/>
    <AdminSider/>
    <div className='ml-[23rem]'>User_Selections</div>
    </>
  )
}

export default User_Selections