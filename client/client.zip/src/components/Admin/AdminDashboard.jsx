import React from 'react'
import Logout from '../../pages/Logout'
import MainHeader from '../../pages/MainHeader'
import AdminSider from './AdminSider'

function AdminDashboard() {
  return (
    <>
    <MainHeader/>
    <AdminSider/>
    
   <div className=" ml-[23rem]">

   </div>
      
    </>
  )
}

export default AdminDashboard